# System Attacks


#### Malware "Malicious Software"

Malware is any software used to misuse computer systems with the intent to:

- Cause denial of service
- Spy on users activity
- Get unauthorized contorl over one or more computer systems
- Cause other maclicious activities 

## Password Cracking

### Unshadow
```
unshadow passwd shadow > crackme
```

### John The Ripper
```
john -wordlist <path to wordlist> -users=<users file> <hashfile>
```
